
# Revolut Home Task

This notebook contains data formatting in Python and embedded Tableau generated charts. It contains analysis of Revolut KYC data executed by Veritas API



```python
import numpy as np 
import pandas as pnd
import scipy as sp 
import matplotlib.pyplot as plt #data visualisation
from matplotlib.pyplot import pie, axis, show
import seaborn as sb
import json
import ast
import sys
```

### Load and Format Data


```python
docrep=pnd.read_csv("C:\Revolut_Challenge_Prakhyath\doc_reports_sample.csv")
```


```python
facerep=pnd.read_csv("C:\Revolut_Challenge_Prakhyath\\face_reports_sample.csv")
```


```python
docrep.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>user_id</th>
      <th>result</th>
      <th>visual_authenticity_result</th>
      <th>image_integrity_result</th>
      <th>face_detection_result</th>
      <th>image_quality_result</th>
      <th>created_at</th>
      <th>supported_document_result</th>
      <th>conclusive_document_quality_result</th>
      <th>colour_picture_result</th>
      <th>data_validation_result</th>
      <th>data_consistency_result</th>
      <th>data_comparison_result</th>
      <th>attempt_id</th>
      <th>police_record_result</th>
      <th>compromised_document_result</th>
      <th>properties</th>
      <th>sub_result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>27241</td>
      <td>8190909e566647a5b6afeee9b4ec6c6a</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-05-25 08:38:56</td>
      <td>clear</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>clear</td>
      <td>NaN</td>
      <td>clear</td>
      <td>30e11e95e30748f485a2271ca5e6abb8</td>
      <td>clear</td>
      <td>NaN</td>
      <td>{'gender': 'Female', 'document_type': 'driving...</td>
      <td>clear</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28369</td>
      <td>6b62136dfde348a99855e350294aaf5d</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-05-31 08:12:51</td>
      <td>clear</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>clear</td>
      <td>NaN</td>
      <td>clear</td>
      <td>4c0bfde8eb2249ed820e1f61d3ec3e33</td>
      <td>clear</td>
      <td>NaN</td>
      <td>{'gender': 'Male', 'document_type': 'driving_l...</td>
      <td>clear</td>
    </tr>
    <tr>
      <th>2</th>
      <td>27988</td>
      <td>73679363dccc46fa9f34a4fefd0d76e3</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-05-29 15:07:04</td>
      <td>clear</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>c5004fd1fc1d4e36a11433b70d960867</td>
      <td>clear</td>
      <td>NaN</td>
      <td>{'gender': 'Male', 'nationality': 'GBR', 'docu...</td>
      <td>clear</td>
    </tr>
    <tr>
      <th>3</th>
      <td>27529</td>
      <td>07857065dfa64db386739ec4fff47856</td>
      <td>consider</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-05-26 19:00:35</td>
      <td>clear</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>clear</td>
      <td>clear</td>
      <td>consider</td>
      <td>e4b26d4ddda545c9931a0a845cd65109</td>
      <td>clear</td>
      <td>NaN</td>
      <td>{'gender': 'Male', 'nationality': 'PER', 'docu...</td>
      <td>caution</td>
    </tr>
    <tr>
      <th>4</th>
      <td>47987</td>
      <td>9f887805b2af49069349ff107e0bca01</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-05-29 14:38:21</td>
      <td>clear</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>clear</td>
      <td>clear</td>
      <td>clear</td>
      <td>8ead2b23ef664e4d85fae798a7d5d52c</td>
      <td>clear</td>
      <td>NaN</td>
      <td>{'gender': 'Male', 'issuing_date': '2011-03', ...</td>
      <td>clear</td>
    </tr>
  </tbody>
</table>
</div>




```python
facerep.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>user_id</th>
      <th>result</th>
      <th>face_comparison_result</th>
      <th>created_at</th>
      <th>facial_image_integrity_result</th>
      <th>visual_authenticity_result</th>
      <th>properties</th>
      <th>attempt_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>58</td>
      <td>ecee468d4a124a8eafeec61271cd0da1</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-06-20 17:50:43</td>
      <td>clear</td>
      <td>clear</td>
      <td>{}</td>
      <td>9e4277fc1ddf4a059da3dd2db35f6c76</td>
    </tr>
    <tr>
      <th>1</th>
      <td>76</td>
      <td>1895d2b1782740bb8503b9bf3edf1ead</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-06-20 13:28:00</td>
      <td>clear</td>
      <td>clear</td>
      <td>{}</td>
      <td>ab259d3cb33b4711b0a5174e4de1d72c</td>
    </tr>
    <tr>
      <th>2</th>
      <td>217</td>
      <td>e71b27ea145249878b10f5b3f1fb4317</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-06-18 21:18:31</td>
      <td>clear</td>
      <td>clear</td>
      <td>{}</td>
      <td>2b7f1c6f3fc5416286d9f1c97b15e8f9</td>
    </tr>
    <tr>
      <th>3</th>
      <td>221</td>
      <td>f512dc74bd1b4c109d9bd2981518a9f8</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-06-18 22:17:29</td>
      <td>clear</td>
      <td>clear</td>
      <td>{}</td>
      <td>ab5989375b514968b2ff2b21095ed1ef</td>
    </tr>
    <tr>
      <th>4</th>
      <td>251</td>
      <td>0685c7945d1349b7a954e1a0869bae4b</td>
      <td>clear</td>
      <td>clear</td>
      <td>2017-06-18 19:54:21</td>
      <td>clear</td>
      <td>clear</td>
      <td>{}</td>
      <td>dd1b0b2dbe234f4cb747cc054de2fdd3</td>
    </tr>
  </tbody>
</table>
</div>




```python
propdf=docrep[['user_id','attempt_id','properties']]
```


```python
propdfnew = pnd.DataFrame()
for index, row in propdf.iterrows():
    #print(type(row['properties']))
    dict=ast.literal_eval(row['properties'])
    #print(type(dict))
    #print(dict)
    for key in dict:
       # type(dict[key])
       propdfnew.at[index,'attempt_id']=row['attempt_id']
       propdfnew.at[index,'user_id']=row['user_id']
       propdfnew.at[index,key]=dict[key]
            
            
```


```python
docrep = pnd.merge(docrep, propdfnew, on='attempt_id')
```


```python
propdfnew.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>attempt_id</th>
      <th>user_id</th>
      <th>gender</th>
      <th>document_type</th>
      <th>date_of_expiry</th>
      <th>issuing_country</th>
      <th>nationality</th>
      <th>issuing_date</th>
      <th>issuing_state</th>
      <th>document_version</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>30e11e95e30748f485a2271ca5e6abb8</td>
      <td>8190909e566647a5b6afeee9b4ec6c6a</td>
      <td>Female</td>
      <td>driving_licence</td>
      <td>2023-12-05</td>
      <td>GBR</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4c0bfde8eb2249ed820e1f61d3ec3e33</td>
      <td>6b62136dfde348a99855e350294aaf5d</td>
      <td>Male</td>
      <td>driving_licence</td>
      <td>2020-05-13</td>
      <td>GBR</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>c5004fd1fc1d4e36a11433b70d960867</td>
      <td>73679363dccc46fa9f34a4fefd0d76e3</td>
      <td>Male</td>
      <td>passport</td>
      <td>2023-11-15</td>
      <td>GBR</td>
      <td>GBR</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>e4b26d4ddda545c9931a0a845cd65109</td>
      <td>07857065dfa64db386739ec4fff47856</td>
      <td>Male</td>
      <td>passport</td>
      <td>2021-01-27</td>
      <td>PER</td>
      <td>PER</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8ead2b23ef664e4d85fae798a7d5d52c</td>
      <td>9f887805b2af49069349ff107e0bca01</td>
      <td>Male</td>
      <td>national_identity_card</td>
      <td>NaN</td>
      <td>FRA</td>
      <td>NaN</td>
      <td>2011-03</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
docrep.shape
```




    (4991, 28)




```python
for index, row in propdf.iterrows():
    print(index)
    print(propdf.loc[index,'attempt_id'])
    break;
```

    0
    30e11e95e30748f485a2271ca5e6abb8
    


```python
docrep.to_csv(r'C:\Revolut_Challenge_Prakhyath\document_report_reformat.csv', index = False)
```

### Exploratory Data Analysis

#### Document Report

Document report has seen a significant upswing in the number of failures


```python
docrep['result'].value_counts().plot(kind='bar',stacked=True,legend=True)
#df = pnd.DataFrame(docrep['result'].value_counts(), index=docrep.index)
#ax = df.plot.bar(rot=0)
#docrep['result'].apply(pnd.value_counts).plot.pie(subplots=True)

```




    <matplotlib.axes._subplots.AxesSubplot at 0x29870907ef0>




![png](output_16_1.png)


Note that the system is still working for the majority of cases. <br>

A consistent upward trend for fails (value=consider) has developed since June and this rate has further increased slightly in September. There is nothing obvious in the change log of the API that would correspond to this increase
![passvsfail.jpg](attachment:passvsfail.jpg)


```python
#docrep['created_at'] = docrep['created_at'].astype('datetime64')
#docrep['visual_authenticity_result'] = docrep['visual_authenticity_result'].astype('category')
#docrep['result'] = docrep['result'].astype('category')
#docrep['image_integrity_result']=docrep['image_integrity_result'].astype('category')
#docrep['face_detection_result']=docrep['face_detection_result'].astype('category')
#docrep['image_quality_result']=docrep['image_quality_result'].astype('category')
#docrep.dtypes
```


```python
docrep['created_month']=pnd.DatetimeIndex(docrep['created_at']).month
```

![Doc_Result_Consider_Count.png](attachment:Doc_Result_Consider_Count.png)
__Trend of Failed Document Checks (based on Result) as percent of total__ <br>

Breaking down the occurences of 'consider', there is a large increase in the rate of fails in June which increases even further in September. This needs further investigation

Investigating sources of these increases in failures by checking trends of subresults, we can see two highly correlated sub results - __ImageQualityResult__ and __ImageIntegrityResult__

__Result vs ImageIntegrityResult = consider__
![Result_ImageIntegRes_Consider.png](attachment:Result_ImageIntegRes_Consider.png)
__Result vs ImageQualityResult = unidentified__ 
![Result_ImagineQualRes_Consider.png](attachment:Result_ImagineQualRes_Consider.png)


```python
integr_inv=docrep['image_integrity_result']=='consider'
integr_cons=docrep[integr_inv]
```


```python
integr_cons.shape
```




    (448, 29)



Drilling down into the Image Integrity fails - we see that there is no outlier document type that is generating these fails. although they are all on an upwards trajectory with passports showing significant uptrend in quality fails

![integpct_doctype.jpg](attachment:integpct_doctype.jpg)

Another source of fails seems to be the sub result = caution - which is vaguely defined as "if any underlying verification have failed". Further granularity to this data point will provide more insight into the source of these fails. "caution" does not seem to be specific to any particular document
![doctype_subresult.png](attachment:doctype_subresult.png)

There is no geographical information about the Image Quality check fails as there is no associated properties information. The global dispersion of image quality via image integrity check has no outlier country
![global_disp.png](attachment:global_disp.png)

There is a correlation between conclusive document_quality result and subresult with both lending to fails in image_integrity_result. This increase in fails starts markedly in August 
![subres_concl.png](attachment:subres_concl.png)

#### Face Report

The overall fails on the Facial Similarity report seem to be on a down trend <br>

__Fails as a percentage total attempts per month__
![Face_Result_Consider_Count.png](attachment:Face_Result_Consider_Count.png)


The shape of the trend is mainly defined by a drop in bad quality images (as defined by Image Integrity Result)
![FaceResult_FaceImgIntegRes_Consider.png](attachment:FaceResult_FaceImgIntegRes_Consider.png)

### Causes

The other sub results had little to no correlation with the increase in failures of document checks (see Tableau results). So it is safe to assume that the source of the failures may lie with Image Quality and Image Integrity checks. 

Based on the veriatas description of these attributes, the failures seem to stem from 

1. the quality of the images submitted
2. the capability of OCR in recognizing the document (56.6% of fails are due to this)

### Solution

__Document Report__

- Image Integrity Result - the quality of images is one of the bigger factors in the increase in failed attempts. To resolve this, we either 
    - Specify concrete and specific instructions for each document type to users to increase the overall quality of images taken of each document type
    - Consult Veritas on employing further machine learning capabilities where possible to either improve recognition or compensate by enhancing or optimising quality
    - Where sub result value is caution, Vertias should provide further breakdown of underlying verifications as this seems to have a high correlation with conclusive document quality check - which lends to image integrity check
    
- Image Quality Result 
    - Provide properties data for the failed OCR checks to fully understand the demographic of failed documents
    - Build a layer before OCR to optimise quality through image processing (with nueral networks for example)
    - Resolving this would result in a decrease of 56.60% in fails


It is important to note that the system works well in general


```python
#docrep['image_quality_result'].value_counts()
dffail=docrep[docrep.result == 'consider']
x=dffail.loc[dffail.image_quality_result == 'unidentified', 'image_quality_result'].count()/dffail['image_quality_result'].count()
print (x*100)
#dffail.shape
```

    56.580732700135684
    


```python
sys.path
```




    ['',
     'C:\\Users\\murfe\\Anaconda3\\python36.zip',
     'C:\\Users\\murfe\\Anaconda3\\DLLs',
     'C:\\Users\\murfe\\Anaconda3\\lib',
     'C:\\Users\\murfe\\Anaconda3',
     'C:\\Users\\murfe\\Anaconda3\\lib\\site-packages',
     'C:\\Users\\murfe\\Anaconda3\\lib\\site-packages\\win32',
     'C:\\Users\\murfe\\Anaconda3\\lib\\site-packages\\win32\\lib',
     'C:\\Users\\murfe\\Anaconda3\\lib\\site-packages\\Pythonwin',
     'C:\\Users\\murfe\\Anaconda3\\lib\\site-packages\\IPython\\extensions',
     'C:\\Users\\murfe\\.ipython']


